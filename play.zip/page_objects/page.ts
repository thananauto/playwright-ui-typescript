import  HomePage  from './login.page'
import Checkout from './checkout.page'
import ProductInfo from './product.info'
import ProductCartPage from './product.list.cart'

export {HomePage, Checkout,ProductCartPage, ProductInfo}

