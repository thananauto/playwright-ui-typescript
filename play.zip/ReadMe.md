Install the playwright


Run the script in UI mode `npx playwright test --ui`